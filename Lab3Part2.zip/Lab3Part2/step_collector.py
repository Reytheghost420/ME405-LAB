import os
import re
import csv
import time
from datetime import datetime

import serial
import matplotlib.pyplot as plt


# -------------------------
# User settings
# -------------------------
PORT = "COM5"          # Windows example. Change to your Nucleo port (e.g. COM3).
BAUD = 115200          # USB_VCP ignores baud on some boards, but keep it consistent.
TIMEOUT = 0.2

# Choose which motor to run for each test:
# Use 'l' or 'r' if your firmware starts immediately on those.
# If your firmware uses 'g' to run after selecting, set MOTOR_CMD='g' and SELECT_CMD to 'l'/'r'.
MOTOR_SIDE = "l"       # 'l' or 'r'
USE_G_TRIGGER = False  # True if you want to select motor then press 'g'

# Test parameters
KP = 0.05
KI = 0.002
SETPOINT = 5000.0      # cps

# Data collection
LOG_DIR = os.path.join(os.path.dirname(__file__), "Collection Log")
os.makedirs(LOG_DIR, exist_ok=True)


# -------------------------
# Helpers
# -------------------------
FLOAT_LINE_RE = re.compile(r"^\s*([0-9]*\.?[0-9]+)\s*,\s*([\-0-9]*\.?[0-9]+)\s*$")

def ts_name():
    # mm_dd_HH_MM_SS
    return datetime.now().strftime("%m_%d_%H_%M_%S")

def write_line(ser: serial.Serial, s: str):
    # Send exactly one-character commands like 'k', 's', 'l', 'r', 'g'
    ser.write(s.encode("utf-8"))

def write_text(ser: serial.Serial, s: str):
    # For multichar entry: "0.05\r"
    ser.write(s.encode("utf-8"))

def read_lines_until_prompt(ser: serial.Serial, stop_phrases, max_seconds=10):
    """Read and return lines until any stop phrase appears."""
    t0 = time.time()
    lines = []
    while time.time() - t0 < max_seconds:
        raw = ser.readline()
        if not raw:
            continue
        try:
            line = raw.decode("utf-8", errors="ignore").strip()
        except Exception:
            continue
        if line:
            lines.append(line)
        for sp in stop_phrases:
            if sp in line:
                return lines
    return lines

def collect_step_data(ser: serial.Serial, max_seconds=10):
    """
    Collect (t, v) from the serial stream until the firmware returns
    to the command prompt (we detect 'Waiting for go command').
    """
    t0 = time.time()
    times = []
    speeds = []
    captured_lines = []

    done_phrase = "Waiting for go command"
    while time.time() - t0 < max_seconds:
        raw = ser.readline()
        if not raw:
            continue
        line = raw.decode("utf-8", errors="ignore").strip()
        if not line:
            continue

        captured_lines.append(line)

        if done_phrase in line:
            break

        m = FLOAT_LINE_RE.match(line.replace("    ", " ").replace("\t", " "))
        if m:
            t = float(m.group(1))
            v = float(m.group(2))
            times.append(t)
            speeds.append(v)

    return times, speeds, captured_lines


# -------------------------
# Main routine
# -------------------------
def main():
    print(f"Opening {PORT} ...")
    with serial.Serial(PORT, BAUD, timeout=TIMEOUT) as ser:
        # Give board time to reset/enumerate
        time.sleep(2.0)
        ser.reset_input_buffer()

        # ---- Set gains (k -> kp -> ki) ----
        print("Sending: k (set gains)")
        write_line(ser, "k")
        time.sleep(0.2)

        # Send Kp value + Enter
        print(f"Setting Kp = {KP}")
        write_text(ser, f"{KP}\r")
        time.sleep(0.2)

        # Send Ki value + Enter
        print(f"Setting Ki = {KI}")
        write_text(ser, f"{KI}\r")
        time.sleep(0.4)

        # ---- Set setpoint (s -> value) ----
        print("Sending: s (set setpoint)")
        write_line(ser, "s")
        time.sleep(0.2)

        print(f"Setting setpoint = {SETPOINT}")
        write_text(ser, f"{SETPOINT}\r")
        time.sleep(0.4)

        # Optional: select motor then trigger with g
        if USE_G_TRIGGER:
            # Select motor
            print(f"Selecting motor: {MOTOR_SIDE}")
            write_line(ser, MOTOR_SIDE)
            time.sleep(0.2)

            print("Triggering: g")
            write_line(ser, "g")
        else:
            # Direct run with l/r
            print(f"Running motor with: {MOTOR_SIDE}")
            write_line(ser, MOTOR_SIDE)

        # ---- Collect data ----
        print("Collecting data...")
        times, speeds, lines = collect_step_data(ser, max_seconds=15)

        if len(times) == 0:
            print("No numeric data captured. Here are the last lines seen:")
            for l in lines[-30:]:
                print(l)
            return

        # ---- Save CSV ----
        stamp = ts_name()
        csv_path = os.path.join(LOG_DIR, f"{stamp}.csv")
        png_path = os.path.join(LOG_DIR, f"{stamp}.png")

        with open(csv_path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["time_s", "speed_cps"])
            for t, v in zip(times, speeds):
                w.writerow([t, v])

        # ---- Plot ----
        plt.figure()
        plt.plot(times, speeds)
        plt.xlabel("Time [s]")
        plt.ylabel("Speed [cps]")
        plt.title(f"Step response ({MOTOR_SIDE}), sp={SETPOINT}, Kp={KP}, Ki={KI}")
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(png_path, dpi=200)
        plt.close()

        print(f"Saved: {csv_path}")
        print(f"Saved: {png_path}")


if __name__ == "__main__":
    main()
